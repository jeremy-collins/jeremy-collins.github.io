#!/usr/bin/env bash
# claude-vault-starter setup — idempotent, loud on failure. Re-run any time.
set -euo pipefail

KIT="$(cd "$(dirname "$0")" && pwd)"
VAULT="${VAULT_DIR:-$HOME/vault}"
YES="${1:-}"
# all | none | comma list of: archive, comment-loop  (gates ACTIVE wiring only —
# bin/ scripts always install; they are inert until you call or cron them)
FEATURES="${STARTER_FEATURES:-all}"

has() { case ",$FEATURES," in *",$1,"*|*",all,"*) return 0 ;; *) return 1 ;; esac; }

say() { printf '\n\033[1m== %s\033[0m\n' "$*"; }

say "claude-vault-starter → vault: $VAULT (override with VAULT_DIR=...) · features: $FEATURES"

# preflight — fail loud and early with the exact fix
for c in git python3 crontab; do
  command -v "$c" >/dev/null || { echo "missing '$c' — install it and re-run" >&2; exit 1; }
done
git config --get user.email >/dev/null || {
  printf 'git identity not set — run:\n  git config --global user.name  "Your Name"\n  git config --global user.email "you@example.com"\nthen re-run setup.sh\n' >&2
  exit 1
}

# 1 · vault repo + union merge
mkdir -p "$VAULT"
[ -d "$VAULT/.git" ] || { git -C "$VAULT" init -q; echo "initialized git repo"; }
if [ ! -f "$VAULT/.gitattributes" ] || ! grep -q 'merge=union' "$VAULT/.gitattributes"; then
  cat "$KIT/dot.gitattributes" >> "$VAULT/.gitattributes"
  echo "installed *.md merge=union"
fi
mkdir -p "$VAULT/Conversations" "$VAULT/Meta"
[ -f "$VAULT/RECENT.md" ] || printf '# Recent Activity\n' > "$VAULT/RECENT.md"

# 2 · scripts on PATH + state dir
mkdir -p "$HOME/.local/bin" "$HOME/.vault"
find "$KIT/bin" -maxdepth 1 -type f -exec install -m 755 {} "$HOME/.local/bin/" \;
echo "installed $(find "$KIT/bin" -maxdepth 1 -type f -printf '%f ' )→ ~/.local/bin"
if [ ! -f "$HOME/.vault/crontab.template" ]; then
  if has archive; then
    cp "$KIT/crontab.template" "$HOME/.vault/crontab.template"
  else
    grep -v -e 'safety net' -e 'save-convo' "$KIT/crontab.template" > "$HOME/.vault/crontab.template"
  fi
fi
if has comment-loop; then
  cp -r "$KIT/comment-loop" "$HOME/.vault/" && echo "comment-loop kit → ~/.vault/comment-loop (see its README)"
fi
case ":$PATH:" in
  *":$HOME/.local/bin:"*) ;;
  *) echo "NOTE: ~/.local/bin is not on PATH — add: export PATH=\"\$HOME/.local/bin:\$PATH\"" ;;
esac

# 3 · Claude Code hooks (merged, never clobbered; backups written on change)
mkdir -p "$VAULT/.claude/hooks" "$HOME/.claude"
install -m 755 "$KIT/hooks/inject_daily_note.sh" "$VAULT/.claude/hooks/inject_daily_note.sh"
python3 "$KIT/merge_settings.py" "$VAULT/.claude/settings.json" session
if has archive; then
  python3 "$KIT/merge_settings.py" "$HOME/.claude/settings.json" stop
fi
# global pointer block: where the vault, RECENT.md, dailies and Distill/ live
python3 "$KIT/claude_md_stub.py" "$VAULT"

# 4 · primary marker (first machine = the one allowed to send)
if [ ! -f "$HOME/.vault/.is_primary" ]; then
  touch "$HOME/.vault/.is_primary"
  echo "marked this machine PRIMARY (rm ~/.vault/.is_primary on secondary machines)"
fi

# 5 · crontab (rendered from the template; shown before touching anything)
say "crontab this would install:"
"$HOME/.local/bin/deploy-crontab" --render
if [ "$YES" = "--yes" ]; then REPLY=y; else read -r -p "install crontab now? [y/N] " REPLY; fi
case "$REPLY" in
  y|Y) "$HOME/.local/bin/deploy-crontab" --install ;;
  *)   echo "skipped — review with 'deploy-crontab --diff', apply with 'deploy-crontab --install'" ;;
esac

# 6 · first commit + one sync pass
cd "$VAULT"
if [ -n "$(git status --porcelain)" ]; then
  git add -A && git commit -q -m "claude-vault-starter setup ($(hostname))"
fi
"$HOME/.local/bin/vault-sync"

say "done. next steps:"
cat <<'EOF'
  · optional backup/sync:  gh repo create vault --private --source ~/vault --push
  · write today's note:    ~/vault/$(date +%F).md
  · open a Claude session in ~/vault — it will load today's note automatically
EOF

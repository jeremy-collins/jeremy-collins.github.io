#!/usr/bin/env bash
# SessionStart hook: inject today's daily note (first 1500 bytes) plus pointers
# to the 3 most recent non-empty dailies. Claude Code truncates hook output at
# 2KB — inject a head + pointers and let the model Read the rest on demand.
set -uo pipefail

VAULT="${CLAUDE_PROJECT_DIR:-${VAULT_DIR:-$HOME/vault}}"
TODAY="$VAULT/$(date +%F).md"

recent=""
for f in $(ls "$VAULT"/20??-??-??.md 2>/dev/null | sort -r | head -6); do
  [ -s "$f" ] && [ "$f" != "$TODAY" ] && recent="$recent$(basename "$f") "
done
recent="$(echo "$recent" | awk '{print $1, $2, $3}')"
[ -n "${recent// /}" ] && echo "Recent non-empty daily notes: $recent— Read them for context."

if [ -s "$TODAY" ]; then
  echo "## Today's note ($(basename "$TODAY"))"
  head -c 1500 "$TODAY"
  if [ "$(stat -c%s "$TODAY")" -gt 1500 ]; then
    printf '\n[truncated — Read %s for the rest]\n' "$TODAY"
  fi
fi
exit 0

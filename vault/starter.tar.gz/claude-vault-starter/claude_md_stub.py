#!/usr/bin/env python3
"""Merge the vault pointer block into ~/.claude/CLAUDE.md.

usage: claude_md_stub.py <vault-path>

The block is marker-delimited; re-runs replace only the block, everything
else in the file is untouched. A .bak is written before any change. This is
a pointer (where the vault and its indexes live), not a preference.
"""
import os
import shutil
import sys

START, END = "<!-- claude-vault-starter:start -->", "<!-- claude-vault-starter:end -->"
vault = sys.argv[1].replace(os.path.expanduser("~"), "~", 1)
path = os.path.expanduser("~/.claude/CLAUDE.md")

block = f"""{START}
## Vault
My notes live in `{vault}` (a git repo). `{vault}/RECENT.md` lists recent Claude Code
sessions newest-first with ids linking to full exports in `{vault}/Conversations/` — read it
when I refer to earlier work ("like last time", "what was I doing"). Daily notes are
`{vault}/YYYY-MM-DD.md`; weekly summaries, when present, are in `{vault}/Distill/`.
`Meta/Vault Setup.md` says what automation is running. Do not edit generated blocks
(project-context, vault-doctor output) by hand.
{END}
"""

existing = ""
if os.path.exists(path):
    with open(path) as f:
        existing = f.read()
    shutil.copy(path, path + ".bak")

if START in existing and END in existing:
    pre, rest = existing.split(START, 1)
    content = pre + block + rest.split(END, 1)[1].lstrip("\n")
    action = "updated"
else:
    content = (existing.rstrip() + "\n\n" if existing.strip() else "") + block
    action = "installed"

os.makedirs(os.path.dirname(path), exist_ok=True)
with open(path, "w") as f:
    f.write(content)
print(f"{action} vault stub in {path} ({len(block)} bytes)")

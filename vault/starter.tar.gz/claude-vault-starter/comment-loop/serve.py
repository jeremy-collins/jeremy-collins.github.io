#!/usr/bin/env python3
"""serve.py — static server + comment API for the visual comment loop.

    python3 serve.py <dir> [port]      (default port 8200, binds 127.0.0.1)

Serves <dir> with Cache-Control: no-store and a JSON comment API:
    GET  /api/comments            -> {"comments": [...]}
    POST /api/comments            {x, y, text, imgs?, page?}  -> pin saved
    POST /api/comments/image      {data: "data:image/...;base64,..."} -> path
    POST /api/comments/delete     {id}
    POST /api/comments/resolve    {id, reply}

Comments persist in <dir>/comments.json; pasted images in <dir>/comment-imgs/.
Put a cloudflared quick tunnel (or tailscale serve) in front to comment from
another device. See README.md for the Claude-side loop.
"""
import base64
import functools
import http.server
import json
import sys
import threading
import time
from pathlib import Path

DIR = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else None
if DIR is None or not DIR.is_dir():
    sys.exit("usage: serve.py <dir> [port]")
PORT = int(sys.argv[2]) if len(sys.argv) > 2 else 8200
CF = DIR / "comments.json"
IMG = DIR / "comment-imgs"
LOCK = threading.Lock()


def load():
    return json.loads(CF.read_text()) if CF.exists() else []


def save(cs):
    tmp = CF.with_suffix(".tmp")
    tmp.write_text(json.dumps(cs, indent=1))
    tmp.replace(CF)


class H(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def log_message(self, *a):
        pass

    def _json(self, obj, code=200):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        if self.path.split("?")[0] == "/api/comments":
            with LOCK:
                self._json({"comments": load()})
        else:
            super().do_GET()

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(n) or b"{}")
        p = self.path.split("?")[0]
        if p == "/api/comments/image":
            data = str(body.get("data", ""))
            if not data.startswith("data:image/") or "," not in data:
                return self._json({"error": "not an image"}, 400)
            ext = data[11 : data.index(";")].lower()
            ext = {"jpeg": "jpg"}.get(ext, ext)
            if ext not in ("png", "jpg", "gif", "webp"):
                ext = "png"
            raw = base64.b64decode(data.split(",", 1)[1])
            if len(raw) > 8_000_000:
                return self._json({"error": "image too large"}, 400)
            IMG.mkdir(exist_ok=True)
            name = f"img{int(time.time() * 1000)}.{ext}"
            (IMG / name).write_bytes(raw)
            return self._json({"ok": True, "path": f"comment-imgs/{name}"})
        with LOCK:
            cs = load()
            if p == "/api/comments":
                text = str(body.get("text", "")).strip()[:2000]
                imgs = [str(u)[:200] for u in (body.get("imgs") or [])][:4]
                if not text and not imgs:
                    return self._json({"error": "empty comment"}, 400)
                c = {
                    "id": f"c{int(time.time() * 1000)}",
                    "page": str(body.get("page", "/"))[:200],
                    "x": round(float(body["x"]), 4),
                    "y": round(float(body["y"]), 4),
                    "text": text,
                    "imgs": imgs,
                    "ts": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "resolved": False,
                    "reply": None,
                }
                cs.append(c)
                save(cs)
                return self._json({"ok": True, "comment": c})
            if p == "/api/comments/delete":
                save([c for c in cs if c["id"] != body["id"]])
                return self._json({"ok": True})
            if p == "/api/comments/resolve":
                for c in cs:
                    if c["id"] == body["id"]:
                        c["resolved"] = True
                        c["reply"] = str(body.get("reply", "")).strip()[:2000] or None
                save(cs)
                return self._json({"ok": True})
        self._json({"error": "not found"}, 404)


http.server.ThreadingHTTPServer(
    ("127.0.0.1", PORT), functools.partial(H, directory=str(DIR))
).serve_forever()

// overlay.js — visual comment pins for any page served by serve.py.
// Include on the page:  <script src="overlay.js"></script>
//
//   shift+click     drop a pin + comment box (enter sends, esc cancels;
//                   pasted images upload and attach)
//   click a pin     see the comment and Claude's reply
//
// Pins anchor to page-fraction coordinates {x, y} of the full document and
// carry the pathname, so one comments.json serves a multi-page site.
(() => {
  const css = `
  .clPin{position:absolute;width:26px;height:26px;margin:-13px 0 0 -13px;border-radius:50% 50% 50% 4px;
    background:#e8a04c;color:#10141a;border:2px solid #fff;box-shadow:0 1px 6px rgba(0,0,0,.4);
    font:700 13px/22px ui-monospace,Menlo,monospace;text-align:center;cursor:pointer;z-index:99990}
  .clPop{position:absolute;z-index:99991;background:#fff;color:#1c2329;border:1px solid #ccc;border-radius:10px;
    box-shadow:0 6px 24px rgba(0,0,0,.25);padding:12px 14px;max-width:340px;font:14px/1.4 system-ui,sans-serif}
  .clPop .r{margin-top:8px;padding:8px 10px;background:#e8f4f2;border-radius:8px;font-size:13px;white-space:pre-wrap}
  .clPop .r::before{content:"claude · ";font:10.5px ui-monospace,monospace;color:#3d8e92}
  .clPop img{max-width:100%;border-radius:6px;margin-top:8px}
  .clBox{position:absolute;z-index:99992;width:320px}
  .clBox textarea{width:100%;height:74px;font:14px/1.4 system-ui,sans-serif;padding:9px 11px;
    border:2px solid #e8a04c;border-radius:10px;box-shadow:0 6px 24px rgba(0,0,0,.3);resize:none;outline:none}
  .clBox .n{font:11px ui-monospace,monospace;color:#e8a04c;min-height:14px}`;
  const style = document.createElement("style");
  style.textContent = css;
  document.head.appendChild(style);

  let comments = [];
  const page = () => location.pathname;
  const doc = () => document.documentElement;

  async function refresh() {
    try {
      const r = await fetch("api/comments");
      comments = (await r.json()).comments || [];
      render();
    } catch (e) {}
  }

  function render() {
    document.querySelectorAll(".clPin").forEach((e) => e.remove());
    comments
      .filter((c) => !c.resolved && (c.page || "/") === page())
      .forEach((c, i) => {
        const p = document.createElement("div");
        p.className = "clPin";
        p.style.left = c.x * doc().scrollWidth + "px";
        p.style.top = c.y * doc().scrollHeight + "px";
        p.textContent = i + 1;
        p.addEventListener("click", (e) => {
          e.stopPropagation();
          pop(c);
        });
        document.body.appendChild(p);
      });
  }

  function esc(t) {
    const d = document.createElement("div");
    d.textContent = t;
    return d.innerHTML;
  }

  function pop(c) {
    clear();
    const el = document.createElement("div");
    el.className = "clPop";
    el.style.left = Math.min(c.x * doc().scrollWidth, doc().scrollWidth - 360) + "px";
    el.style.top = c.y * doc().scrollHeight + 16 + "px";
    el.innerHTML =
      `<div>${esc(c.text)}</div>` +
      (c.imgs || []).map((u) => `<img src="${u}">`).join("") +
      (c.reply ? `<div class="r">${esc(c.reply)}</div>` : "");
    el.addEventListener("click", (e) => e.stopPropagation());
    document.body.appendChild(el);
  }

  function clear() {
    document.querySelectorAll(".clPop,.clBox").forEach((e) => e.remove());
  }

  function input(px, py) {
    clear();
    const box = document.createElement("div");
    box.className = "clBox";
    box.style.left = Math.min(px, doc().scrollWidth - 340) + "px";
    box.style.top = py + "px";
    box.innerHTML = `<textarea placeholder="comment for claude — enter to send · paste images"></textarea><div class="n"></div>`;
    document.body.appendChild(box);
    const ta = box.querySelector("textarea");
    const note = box.querySelector(".n");
    const imgs = [];
    ta.focus();
    ta.addEventListener("paste", async (ev) => {
      const items = [...((ev.clipboardData || {}).items || [])].filter((i) => i.type.startsWith("image/"));
      if (!items.length) return;
      ev.preventDefault();
      note.textContent = "uploading…";
      for (const it of items) {
        const f = it.getAsFile();
        if (!f) continue;
        const dataUrl = await new Promise((res) => {
          const r = new FileReader();
          r.onload = () => res(r.result);
          r.readAsDataURL(f);
        });
        try {
          const resp = await fetch("api/comments/image", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ data: dataUrl }),
          });
          const j = await resp.json();
          if (j.path) imgs.push(j.path);
        } catch (e) {}
      }
      note.textContent = imgs.length ? `📎 ${imgs.length} attached` : "upload failed";
    });
    ta.addEventListener("keydown", async (e) => {
      e.stopPropagation();
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        const text = ta.value.trim();
        if (!text && !imgs.length) return;
        await fetch("api/comments", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ page: page(), x: px / doc().scrollWidth, y: py / doc().scrollHeight, text, imgs }),
        });
        box.remove();
        refresh();
      } else if (e.key === "Escape") box.remove();
    });
  }

  addEventListener("click", (e) => {
    if (e.target.closest(".clPin,.clPop,.clBox,a,button,input,textarea")) return;
    if (document.querySelector(".clBox textarea")?.value.trim()) return;
    if (document.querySelector(".clPop,.clBox")) return clear();
    if (e.shiftKey) input(e.pageX, e.pageY);
  });
  addEventListener("resize", render);

  refresh();
  setInterval(refresh, 15000);
})();

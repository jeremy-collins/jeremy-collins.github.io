# comment-loop — visual comments that wake a Claude session

Iterate on any locally-served page by clicking on it instead of describing it:
you shift+click a pin in the browser, a Claude Code session wakes up, makes the
edit, and replies on the pin. The page auto-refreshes its pins every 15s.

## Run it

```bash
python3 serve.py <your-site-dir> 8200        # static server + comment API
# add to the page you're iterating on:
#   <script src="overlay.js"></script>       (copy overlay.js into the dir)
# optional, to comment from your phone/another machine:
cloudflared tunnel --url http://localhost:8200
```

## Close the loop (the Claude side)

In a Claude Code session, say:

> Watch `<dir>/comments.json` with a Monitor. For each new unresolved comment:
> read its `page`/`x`/`y` to find what it points at (if it has `imgs`, Read
> those files), make the edit, then set `resolved: true` and a short `reply`
> on that comment in comments.json.

That's the whole protocol. The comment file is the API: the server reads it
from disk on every request, so Claude editing the JSON directly is equivalent
to calling `/api/comments/resolve`. Resolved pins disappear from the page;
replies show when a pin is clicked before it resolves.

## Notes

- `comments.json` and `comment-imgs/` live next to your site — keep them in
  git and the review record travels with the project.
- The server binds 127.0.0.1 only; a tunnel is the intended way in.
- Everything is stdlib + vanilla JS. No build step, no dependencies.

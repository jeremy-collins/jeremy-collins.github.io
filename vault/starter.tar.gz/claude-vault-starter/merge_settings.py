#!/usr/bin/env python3
"""Merge one starter hook into a Claude Code settings.json without clobbering.

usage: merge_settings.py <settings-path> <session|stop>

Existing hooks of the same type are left untouched (printed, skipped).
A .bak backup is written before any change. Malformed JSON fails loudly.
"""
import json
import os
import shutil
import sys

HOOKS = {
    "session": (
        "SessionStart",
        {"hooks": [{
            "type": "command",
            "command": "\"$CLAUDE_PROJECT_DIR\"/.claude/hooks/inject_daily_note.sh",
            "timeout": 10,
            "statusMessage": "Injecting daily note",
        }]},
    ),
    "stop": (
        "Stop",
        {"hooks": [{
            "type": "command",
            "command": "save-convo >/dev/null 2>&1 || true",
            "statusMessage": "Saving conversation to vault",
        }]},
    ),
}

path, mode = sys.argv[1], sys.argv[2]
key, entry = HOOKS[mode]

cfg = {}
if os.path.exists(path):
    with open(path) as f:
        cfg = json.load(f)

hooks = cfg.setdefault("hooks", {})
if key in hooks:
    print(f"{key} hook already present in {path} — left untouched")
    sys.exit(0)

if os.path.exists(path):
    shutil.copy(path, path + ".bak")
hooks[key] = [entry]
os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
with open(path, "w") as f:
    json.dump(cfg, f, indent=2)
    f.write("\n")
print(f"installed {key} hook → {path}")

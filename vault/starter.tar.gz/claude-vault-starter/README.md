# claude-vault-starter

A minimal, self-contained version of the vault + agent loop from the talk.
One folder of markdown that is simultaneously your notes, a git repo, and the
context every Claude Code session starts with — plus the cron loop that keeps
it synced and the hooks that save every session.

No personal config, no opinions imposed: these are the mechanisms only.

## Install (~5 minutes)

**Assisted (recommended)** — paste into any Claude Code session:

> Fetch https://jeremy-collins.com/vault/PROMPT.md (curl works) and
> follow its instructions to set up claude-vault-starter for me.

It looks at your machine first (how many Claude sessions you have, which
repos, whether you already keep notes), asks four short questions about how
you work, proposes a shaped setup — Seed / Scholar / Operator — installs only
that, and then walks you through one real loop so you leave with a habit, not
a parts list. Nothing that messages you is installed unless you ask.

**By hand:**

```bash
./setup.sh          # idempotent — safe to re-run any time
```

Feature-gate with `STARTER_FEATURES` — `all` (default), `none` (core only),
or a comma list of `archive` (Stop hook + save-convo cron line) and
`comment-loop`. Scripts in `bin/` always install; they are inert until you
call or cron them.

What it does (and tells you as it goes):

1. Creates `~/vault` as a git repo (or uses your existing one) with
   `*.md merge=union` — two machines editing the same note never conflict.
2. Installs 8 small scripts to `~/.local/bin`: `vault-sync`, `save-convo`,
   `vault-context`, `vault-run-if-primary`, `kssh`, `deploy-crontab`,
   `claude-slack`, `example-agent`.
3. Installs two Claude Code hooks (merged into your settings, never
   clobbered; Stop only with the `archive` feature):
   - **SessionStart** — injects today's `YYYY-MM-DD.md` note into every session
   - **Stop** — exports every finished session to `vault/Conversations/` + a
     one-line index in `RECENT.md`

   …and a marker-delimited pointer block in `~/.claude/CLAUDE.md` telling
   every session where the vault, `RECENT.md`, daily notes and `Distill/` are.
4. Shows you the crontab it wants (sync every 5 min) and installs it only if
   you say yes. The crontab is rendered from `~/.vault/crontab.template` —
   edit the template, not `crontab -e`.
5. Marks this machine primary (`~/.vault/.is_primary`). On a second machine,
   `rm` that file — it still syncs, but any outgoing agents you add stay quiet.

## After setup

- **Back it up / sync a second machine** (optional but recommended):
  ```bash
  gh repo create vault --private --source ~/vault --push
  # second machine: git clone <your-repo> ~/vault && ./setup.sh
  ```
- **Point Obsidian at `~/vault`** if you want a nice editing surface — the
  system doesn't need it, it's just markdown.
- **Write today's note** at `~/vault/$(date +%F).md`. Open any Claude session
  in the vault: it already knows what today is about.

## The pieces

| script | what it does |
|---|---|
| `vault-sync` | commit-first sync: commit → pull (rebase, merge fallback) → push. Nothing saved to disk can be lost; conflicts in `.md` auto-resolve via union merge. |
| `vault-context` | what a session started here will load and how much: global/project CLAUDE.md, the SessionStart hook's real output vs the 2 KB cap, memory index, RECENT.md — bytes and ~tokens, with bloat warnings. Context is a budget; this shows the bill. |
| `save-convo` | export the latest Claude Code session to `Conversations/` and index it in `RECENT.md` (`--all` sweeps everything, used by cron as a safety net). |
| `vault-run-if-primary` | 7-line guard: wraps outgoing cron jobs so exactly one of your machines sends. |
| `kssh <host> [session]` | ssh into a persistent remote tmux session; auto-reconnects on transport failure (exit 255) with jittered backoff. Wifi drops stop mattering. |
| `deploy-crontab` | render `crontab.template` → `--diff` to review, `--install` to apply. Cron as a build artifact. |
| `claude-slack` | agents DM you and wait for your reply: `send` / `ask <delay> "q"` (grace window — kill it in time and nothing posts) / `wait <ts>`. Needs two values in `~/.vault/slack.env` (see script header; bot scopes `chat:write` + `im:write` + `im:history`). |
| `example-agent` | a working template of the whole pattern — guard → vault context → `claude -p` → `claude-slack send`. Clone it into your first agent. |
| `comment-loop/` | visual comments for any locally-served page: shift+click pins wake a Claude session that edits and replies. Installed to `~/.vault/comment-loop`; its README has the 3-step recipe. |

## Bells & whistles (opt-in downloads)

Bigger pieces live as 14 standalone stdlib-only scripts in `extras/` on the
site the kit came from:

- **context layer** — `project-context` (hourly: per-repo `CLAUDE.local.md`
  built from the vault notes, daily notes, sessions and calendar lines that
  mention that project; git-excluded), `session-distill` (weekly: a week of
  `Conversations/` → one `Distill/` note of decisions, open threads, things
  learned), `refine-prefs`, `vault-organizer`, `vault-doctor` (now also
  audits installed cron modules and when each last wrote anything)
- **agents that reach out to you** — `task-worker` (pitches a plan for a
  `Tasks.md` task, does it on "yes"), `task-nagger`, `journal-prompt`,
  `vault-digest`
- **pipelines in** — `todoist-tasks`, `calendar-sync`
- **tools** — `vault-tokens`, `test-fix`, `reminder`

The assisted setup (PROMPT.md) offers them; or fetch one by hand into
`~/.local/bin` and `chmod +x` it — each script's docstring says what it
needs and its typical cron line.

## Deliberately not included

Preferences (coding style files, output styles, permission modes) and
pipelines tied to one person's accounts (eval watchers, channel responder,
account rotation). Those are shaped around one person's setup — build your
own on these rails, or ask Jeremy to walk you through his.
